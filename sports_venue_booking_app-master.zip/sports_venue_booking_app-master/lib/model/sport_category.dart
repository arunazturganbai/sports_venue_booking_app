class SportCategory {
  String name;
  String image;

  SportCategory({required this.name, required this.image});
}
